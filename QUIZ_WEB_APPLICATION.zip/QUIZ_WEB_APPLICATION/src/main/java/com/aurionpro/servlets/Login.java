package com.aurionpro.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.aurionpro.connection.JDBCConnection;
import com.aurionpro.util.PasswordUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/login")
public class Login extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String username = req.getParameter("username");
        String password = PasswordUtil.hashPassword(req.getParameter("password"));

        res.setContentType("text/html");
        PrintWriter out = res.getWriter();

        try (Connection conn = JDBCConnection.getConnection()) {
            PreparedStatement ps = conn.prepareStatement(
                    "SELECT * FROM users WHERE username=? AND password=?");
            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                HttpSession session = req.getSession();
                session.setAttribute("username", username);
                res.sendRedirect("welcome");
            } else {
                // Re-render login page with error message
                out.println("<!DOCTYPE html>");
                out.println("<html lang='en'>");
                out.println("<head>");
                out.println("<meta charset='UTF-8'>");
                out.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
                out.println("<title>Login</title>");
                out.println("<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'>");
                out.println("<style>");
                out.println("body { background: linear-gradient(to right, #ff9966, #ff5e62); height: 100vh; display: flex; justify-content: center; align-items: center; }");
                out.println(".login-container { background: white; padding: 20px; border-radius: 10px; box-shadow: 0 4px 10px rgba(0,0,0,0.3); width: 350px; }");
                out.println("</style>");
                out.println("</head>");
                out.println("<body>");
                out.println("<div class='login-container'>");
                out.println("<h2 class='text-center mb-3'>Login</h2>");
                out.println("<div class='alert alert-danger' role='alert'>Invalid username or password!</div>");
                out.println("<form method='post' action='login'>");
                out.println("<div class='mb-3'>");
                out.println("<label class='form-label'>Username</label>");
                out.println("<input type='text' name='username' class='form-control' value='" + username + "' required>");
                out.println("</div>");
                out.println("<div class='mb-3'>");
                out.println("<label class='form-label'>Password</label>");
                out.println("<input type='password' name='password' class='form-control' required>");
                out.println("</div>");
                out.println("<button type='submit' class='btn btn-primary w-100'>Login</button>");
                out.println("</form>");
                out.println("</div>");
                out.println("</body>");
                out.println("</html>");
            }
        } catch (Exception e) {
            e.printStackTrace(out);
        }
    }
}
