package com.aurionpro.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/question")
public class QuestionServlet extends HttpServlet {
    @SuppressWarnings("unchecked")
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        List<com.aurionpro.model.Question> questions =
                (List<com.aurionpro.model.Question>) session.getAttribute("questions");
        int index = (int) session.getAttribute("currentIndex");

        if (index >= questions.size()) {
            response.sendRedirect("result");
            return;
        }

        // Retrieve saved answers
        Map<Integer, String> answers = (Map<Integer, String>) session.getAttribute("answers");
        if (answers == null) {
            answers = new HashMap<>();
            session.setAttribute("answers", answers);
        }

        com.aurionpro.model.Question q = questions.get(index);
        String savedAnswer = answers.get(q.getId());

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<!DOCTYPE html>");
        out.println("<html lang='en'>");
        out.println("<head>");
        out.println("<meta charset='UTF-8'>");
        out.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
        out.println("<title>Question</title>");
        out.println("<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'>");
        out.println("<style>");
        out.println("body { background: linear-gradient(to right, #00b09b, #96c93d); min-height: 100vh; display: flex; align-items: center; justify-content: center; }");
        out.println(".card { border-radius: 1rem; box-shadow: 0 4px 15px rgba(0,0,0,0.2); }");
        out.println(".option-label { display: block; background: #f8f9fa; padding: 10px; border-radius: 0.5rem; margin-bottom: 10px; cursor: pointer; border: 2px solid transparent; }");
        out.println(".option-label:hover { border-color: #00b09b; background: #e9f7ef; }");
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");
        out.println("<div class='container'>");
        out.println("  <div class='row justify-content-center'>");
        out.println("    <div class='col-md-6'>");
        out.println("      <div class='card p-4'>");
        out.println("        <h4 class='mb-3 text-center'>Question " + (index + 1) + " of " + questions.size() + "</h4>");
        out.println("        <form method='post' action='submitAnswer'>");
        out.println("          <input type='hidden' name='qid' value='" + q.getId() + "'>");
        out.println("          <p class='fw-bold'>" + q.getQuestionText() + "</p>");

        out.println("          <label class='option-label'><input type='radio' name='answer' value='A' " +
                ("A".equals(savedAnswer) ? "checked" : "") + "> " + q.getOptionA() + "</label>");
        out.println("          <label class='option-label'><input type='radio' name='answer' value='B' " +
                ("B".equals(savedAnswer) ? "checked" : "") + "> " + q.getOptionB() + "</label>");
        out.println("          <label class='option-label'><input type='radio' name='answer' value='C' " +
                ("C".equals(savedAnswer) ? "checked" : "") + "> " + q.getOptionC() + "</label>");
        out.println("          <label class='option-label'><input type='radio' name='answer' value='D' " +
                ("D".equals(savedAnswer) ? "checked" : "") + "> " + q.getOptionD() + "</label>");

        out.println("          <div class='text-center mt-4'>");
        if (index > 0) {
            out.println("            <button type='submit' name='action' value='prev' class='btn btn-lg btn-secondary px-4 me-2'>Previous</button>");
        }
        out.println("            <button type='submit' name='action' value='next' class='btn btn-lg btn-primary px-4'>Next</button>");
        out.println("          </div>");
        out.println("        </form>");
        out.println("      </div>");
        out.println("    </div>");
        out.println("  </div>");
        out.println("</div>");
        out.println("</body>");
        out.println("</html>");
    }
}
