package com.aurionpro.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.aurionpro.model.Question;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/submitAnswer")
public class SubmitAnswer extends HttpServlet {
    @SuppressWarnings("unchecked")
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        Integer indexObj = (Integer) session.getAttribute("currentIndex");
        if (indexObj == null) indexObj = 0;
        int index = indexObj;

        List<Question> questions = (List<Question>) session.getAttribute("questions");
        if (questions == null) {
            response.sendRedirect("welcome");
            return;
        }

        Map<Integer, String> answers = (Map<Integer, String>) session.getAttribute("answers");
        if (answers == null) {
            answers = new HashMap<>();
        }

        // Store the current answer
        String answer = request.getParameter("answer");
        String qidStr = request.getParameter("qid");
        if (qidStr != null && answer != null) {
            int qid = Integer.parseInt(qidStr);
            answers.put(qid, answer);
        }
        session.setAttribute("answers", answers);

        // Navigation
        String action = request.getParameter("action");
        if ("next".equals(action)) {
            index++;
        } else if ("prev".equals(action)) {
            index--;
        }

        // End of quiz
        if (index >= questions.size()) {
            // Calculate score
            int score = 0;
            for (Question q : questions) {
                String given = answers.get(q.getId());
                if (given != null && given.length() > 0 &&
                    given.charAt(0) == q.getCorrectOption()) {
                    score++;
                }
            }
            session.setAttribute("score", score);

            // Ensure userId exists
            Integer userId = (Integer) session.getAttribute("userId");
            if (userId == null) {
                userId = 0; // Temporary fallback
                session.setAttribute("userId", userId);
            }

            // ✅ Store results in database
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                try (Connection conn = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/quiz", "root", "Mustafa52!")) {

                    String sql = "INSERT INTO results (user_id, score, total_questions) VALUES (?, ?, ?)";
                    try (PreparedStatement ps = conn.prepareStatement(sql)) {
                        ps.setInt(1, userId);                     // Logged-in user's ID
                        ps.setInt(2, score);                      // Final quiz score
                        ps.setInt(3, questions.size());           // Total questions in quiz
                        ps.executeUpdate();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            response.sendRedirect("result");
            return;
        }

        if (index < 0) index = 0;

        session.setAttribute("currentIndex", index);
        response.sendRedirect("question");
    }
}
