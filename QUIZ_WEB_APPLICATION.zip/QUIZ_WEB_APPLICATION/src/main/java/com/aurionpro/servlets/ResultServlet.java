package com.aurionpro.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;
import java.util.Map;

import com.aurionpro.connection.JDBCConnection;
import com.aurionpro.model.Question;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/result")
public class ResultServlet extends HttpServlet {
    @SuppressWarnings("unchecked")
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session == null || session.getAttribute("questions") == null || session.getAttribute("answers") == null) {
            response.sendRedirect("welcome");
            return;
        }

        List<Question> questions = (List<Question>) session.getAttribute("questions");
        Map<Integer, String> answers = (Map<Integer, String>) session.getAttribute("answers");

        // Get userId from session
        Integer userId = (Integer) session.getAttribute("userId");
        if (userId == null) {
            response.sendRedirect("login");
            return;
        }

        int score = 0;

        // Calculate score
        for (Question q : questions) {
            String userAnswer = answers.get(q.getId());
            if (userAnswer != null && !userAnswer.isEmpty() &&
                userAnswer.charAt(0) == q.getCorrectOption()) {
                score++;
            }
        }

        // Save score in DB
        try (Connection conn = JDBCConnection.getConnection()) {
            PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO results(user_id, score) VALUES(?,?)"
            );
            ps.setInt(1, userId);
            ps.setInt(2, score);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Show result page
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<!DOCTYPE html>");
        out.println("<html lang='en'>");
        out.println("<head>");
        out.println("<meta charset='UTF-8'>");
        out.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
        out.println("<title>Quiz Result</title>");
        out.println("<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'>");
        out.println("<style>");
        out.println("body { background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%); min-height: 100vh; display: flex; align-items: center; justify-content: center; }");
        out.println(".result-card { background: white; border-radius: 1rem; padding: 2rem; box-shadow: 0 4px 20px rgba(0,0,0,0.2); max-width: 900px; width: 100%; }");
        out.println(".correct { color: green; font-weight: bold; }");
        out.println(".wrong { color: red; font-weight: bold; }");
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");
        
        out.println("<div class='result-card'>");
        out.println("<h2 class='text-center mb-4'>🎉 Quiz Completed!</h2>");
        out.println("<p class='text-center fs-5'>Your final score is:</p>");
        out.println("<h1 class='text-center text-success fw-bold'>" + score + " / " + questions.size() + "</h1>");
        out.println("<hr>");
        
        out.println("<h4>📋 Review Your Answers:</h4>");
        out.println("<ul class='list-group'>");
        for (Question q : questions) {
            String userAnswer = answers.get(q.getId());
            out.println("<li class='list-group-item'>");
            out.println("<strong>" + q.getQuestionText() + "</strong><br>");
            out.println("Your Answer: " + (userAnswer != null ? userAnswer : "Not answered") +
                        (userAnswer != null && userAnswer.charAt(0) == q.getCorrectOption() 
                            ? " ✅" : " ❌") + "<br>");
            out.println("Correct Answer: <span class='correct'>" + q.getCorrectOption() + "</span>");
            out.println("</li>");
        }
        out.println("</ul>");
        
        out.println("<div class='text-center mt-4'>");
        out.println("<a href='welcome' class='btn btn-success btn-lg me-2'>Play Again</a>");
        out.println("<a href='logout' class='btn btn-danger btn-lg'>Logout</a>");
        out.println("</div>");
        
        out.println("</div>");
        out.println("</body>");
        out.println("</html>");
    }
}

