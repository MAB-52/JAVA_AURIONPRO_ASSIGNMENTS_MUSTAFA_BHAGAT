package com.aurionpro.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/welcome")
public class WelcomeServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("username") == null) {
            response.sendRedirect("login.html");
            return;
        }

        // ✅ Clear any previous quiz data
        session.removeAttribute("questions");
        session.removeAttribute("answers");
        session.removeAttribute("currentIndex");
        session.removeAttribute("score");

        String username = (String) session.getAttribute("username");

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<!DOCTYPE html>");
        out.println("<html lang=\"en\">");
        out.println("<head>");
        out.println("    <meta charset=\"UTF-8\">");
        out.println("    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">");
        out.println("    <title>Welcome</title>");
        out.println("    <link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css\" rel=\"stylesheet\">");
        out.println("    <style>");
        out.println("        body {");
        out.println("            background: linear-gradient(to right, #00b09b, #96c93d);");
        out.println("            height: 100vh;");
        out.println("            display: flex;");
        out.println("            align-items: center;");
        out.println("            justify-content: center;");
        out.println("            color: white;");
        out.println("        }");
        out.println("        .card {");
        out.println("            border-radius: 1rem;");
        out.println("            box-shadow: 0 4px 15px rgba(0,0,0,0.2);");
        out.println("        }");
        out.println("    </style>");
        out.println("</head>");
        out.println("<body>");
        out.println("    <div class=\"container\">");
        out.println("        <div class=\"row justify-content-center\">");
        out.println("            <div class=\"col-md-5\">");
        out.println("                <div class=\"card text-center p-4\">");
        out.println("                    <h2>Welcome, " + username + "!</h2>");
        out.println("                    <p class=\"mb-4\">Ready to test your knowledge?</p>");
        out.println("                    <a href=\"startQuiz\" class=\"btn btn-primary btn-lg mb-3 w-100\">Start Game</a>");
        out.println("                    <a href=\"logout\" class=\"btn btn-danger btn-lg w-100\">Logout</a>");
        out.println("                </div>");
        out.println("            </div>");
        out.println("        </div>");
        out.println("    </div>");
        out.println("</body>");
        out.println("</html>");
    }
}
