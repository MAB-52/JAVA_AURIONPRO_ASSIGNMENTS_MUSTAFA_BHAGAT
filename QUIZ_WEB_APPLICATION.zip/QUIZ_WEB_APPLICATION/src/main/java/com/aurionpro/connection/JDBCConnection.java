package com.aurionpro.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JDBCConnection {

    public static final String URL = "jdbc:mysql://localhost:3306/quiz";
    public static final String USER = "root";
    public static final String PASSWORD = "Mustafa52!";
    
    public static Connection getConnection() throws SQLException
    {
    	try
    	{
    		//Load and register JDBC Driver...
    		Class.forName("com.mysql.cj.jdbc.Driver");
    	}
    	catch(ClassNotFoundException e)
    	{
    		System.out.println("MySQL Driver Class not found !!!!");
    	}
    	
    	return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}