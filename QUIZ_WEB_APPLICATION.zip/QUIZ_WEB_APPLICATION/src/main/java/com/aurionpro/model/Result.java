package com.aurionpro.model;

import java.sql.Timestamp;

public class Result 
{
    private int id;
    private int userId;
    private int score;
    private Timestamp date;

}
